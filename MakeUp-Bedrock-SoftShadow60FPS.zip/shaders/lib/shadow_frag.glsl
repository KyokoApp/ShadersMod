/* MakeUp - Optimized Single Tap Shadow */
float get_shadow(vec3 the_shadow_pos, float dither) {
    return shadow2D(shadowtex1, the_shadow_pos).r;
}
